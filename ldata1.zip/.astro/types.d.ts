declare module 'astro:content' {
	interface Render {
		'.mdx': Promise<{
			Content: import('astro').MarkdownInstance<{}>['Content'];
			headings: import('astro').MarkdownHeading[];
			remarkPluginFrontmatter: Record<string, any>;
		}>;
	}
}

declare module 'astro:content' {
	interface Render {
		'.md': Promise<{
			Content: import('astro').MarkdownInstance<{}>['Content'];
			headings: import('astro').MarkdownHeading[];
			remarkPluginFrontmatter: Record<string, any>;
		}>;
	}
}

declare module 'astro:content' {
	export { z } from 'astro/zod';

	type Flatten<T> = T extends { [K: string]: infer U } ? U : never;

	export type CollectionKey = keyof AnyEntryMap;
	export type CollectionEntry<C extends CollectionKey> = Flatten<AnyEntryMap[C]>;

	export type ContentCollectionKey = keyof ContentEntryMap;
	export type DataCollectionKey = keyof DataEntryMap;

	// This needs to be in sync with ImageMetadata
	export type ImageFunction = () => import('astro/zod').ZodObject<{
		src: import('astro/zod').ZodString;
		width: import('astro/zod').ZodNumber;
		height: import('astro/zod').ZodNumber;
		format: import('astro/zod').ZodUnion<
			[
				import('astro/zod').ZodLiteral<'png'>,
				import('astro/zod').ZodLiteral<'jpg'>,
				import('astro/zod').ZodLiteral<'jpeg'>,
				import('astro/zod').ZodLiteral<'tiff'>,
				import('astro/zod').ZodLiteral<'webp'>,
				import('astro/zod').ZodLiteral<'gif'>,
				import('astro/zod').ZodLiteral<'svg'>,
				import('astro/zod').ZodLiteral<'avif'>,
			]
		>;
	}>;

	type BaseSchemaWithoutEffects =
		| import('astro/zod').AnyZodObject
		| import('astro/zod').ZodUnion<[BaseSchemaWithoutEffects, ...BaseSchemaWithoutEffects[]]>
		| import('astro/zod').ZodDiscriminatedUnion<string, import('astro/zod').AnyZodObject[]>
		| import('astro/zod').ZodIntersection<BaseSchemaWithoutEffects, BaseSchemaWithoutEffects>;

	type BaseSchema =
		| BaseSchemaWithoutEffects
		| import('astro/zod').ZodEffects<BaseSchemaWithoutEffects>;

	export type SchemaContext = { image: ImageFunction };

	type DataCollectionConfig<S extends BaseSchema> = {
		type: 'data';
		schema?: S | ((context: SchemaContext) => S);
	};

	type ContentCollectionConfig<S extends BaseSchema> = {
		type?: 'content';
		schema?: S | ((context: SchemaContext) => S);
	};

	type CollectionConfig<S> = ContentCollectionConfig<S> | DataCollectionConfig<S>;

	export function defineCollection<S extends BaseSchema>(
		input: CollectionConfig<S>
	): CollectionConfig<S>;

	type AllValuesOf<T> = T extends any ? T[keyof T] : never;
	type ValidContentEntrySlug<C extends keyof ContentEntryMap> = AllValuesOf<
		ContentEntryMap[C]
	>['slug'];

	export function getEntryBySlug<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(
		collection: C,
		// Note that this has to accept a regular string too, for SSR
		entrySlug: E
	): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;

	export function getDataEntryById<C extends keyof DataEntryMap, E extends keyof DataEntryMap[C]>(
		collection: C,
		entryId: E
	): Promise<CollectionEntry<C>>;

	export function getCollection<C extends keyof AnyEntryMap, E extends CollectionEntry<C>>(
		collection: C,
		filter?: (entry: CollectionEntry<C>) => entry is E
	): Promise<E[]>;
	export function getCollection<C extends keyof AnyEntryMap>(
		collection: C,
		filter?: (entry: CollectionEntry<C>) => unknown
	): Promise<CollectionEntry<C>[]>;

	export function getEntry<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(entry: {
		collection: C;
		slug: E;
	}): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof DataEntryMap,
		E extends keyof DataEntryMap[C] | (string & {}),
	>(entry: {
		collection: C;
		id: E;
	}): E extends keyof DataEntryMap[C]
		? Promise<DataEntryMap[C][E]>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(
		collection: C,
		slug: E
	): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof DataEntryMap,
		E extends keyof DataEntryMap[C] | (string & {}),
	>(
		collection: C,
		id: E
	): E extends keyof DataEntryMap[C]
		? Promise<DataEntryMap[C][E]>
		: Promise<CollectionEntry<C> | undefined>;

	/** Resolve an array of entry references from the same collection */
	export function getEntries<C extends keyof ContentEntryMap>(
		entries: {
			collection: C;
			slug: ValidContentEntrySlug<C>;
		}[]
	): Promise<CollectionEntry<C>[]>;
	export function getEntries<C extends keyof DataEntryMap>(
		entries: {
			collection: C;
			id: keyof DataEntryMap[C];
		}[]
	): Promise<CollectionEntry<C>[]>;

	export function reference<C extends keyof AnyEntryMap>(
		collection: C
	): import('astro/zod').ZodEffects<
		import('astro/zod').ZodString,
		C extends keyof ContentEntryMap
			? {
					collection: C;
					slug: ValidContentEntrySlug<C>;
				}
			: {
					collection: C;
					id: keyof DataEntryMap[C];
				}
	>;
	// Allow generic `string` to avoid excessive type errors in the config
	// if `dev` is not running to update as you edit.
	// Invalid collection names will be caught at build time.
	export function reference<C extends string>(
		collection: C
	): import('astro/zod').ZodEffects<import('astro/zod').ZodString, never>;

	type ReturnTypeOrOriginal<T> = T extends (...args: any[]) => infer R ? R : T;
	type InferEntrySchema<C extends keyof AnyEntryMap> = import('astro/zod').infer<
		ReturnTypeOrOriginal<Required<ContentConfig['collections'][C]>['schema']>
	>;

	type ContentEntryMap = {
		"blog": {
"astro-build.md": {
	id: "astro-build.md";
  slug: "astro-build";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"cms-headless-innovazione-costi.md": {
	id: "cms-headless-innovazione-costi.md";
  slug: "cms-headless-innovazione-costi";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"collaborazione-umano-ia-ceazione-contenuti.md": {
	id: "collaborazione-umano-ia-ceazione-contenuti.md";
  slug: "collaborazione-umano-ia-ceazione-contenuti";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"componenti-react-versatili.mdx": {
	id: "componenti-react-versatili.mdx";
  slug: "componenti-react-versatili";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".mdx"] };
"core-web-vitals-approcci-allo-sviluppo-web.md": {
	id: "core-web-vitals-approcci-allo-sviluppo-web.md";
  slug: "core-web-vitals-approcci-allo-sviluppo-web";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"gsap-presente-futuro-animazioni-web.md": {
	id: "gsap-presente-futuro-animazioni-web.md";
  slug: "gsap-presente-futuro-animazioni-web";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"jamastack-futuro.md": {
	id: "jamastack-futuro.md";
  slug: "jamastack-futuro";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"librerie-grafici-js.md": {
	id: "librerie-grafici-js.md";
  slug: "librerie-grafici-js";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"mdx-era.mdx": {
	id: "mdx-era.mdx";
  slug: "mdx-era";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".mdx"] };
"nuove-funzionalità-css.md": {
	id: "nuove-funzionalità-css.md";
  slug: "nuove-funzionalità-css";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"ottimizzazione-della-ricerca-vocale-il-futuro-del-seo.md": {
	id: "ottimizzazione-della-ricerca-vocale-il-futuro-del-seo.md";
  slug: "ottimizzazione-della-ricerca-vocale-il-futuro-del-seo";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"processwire-cms-cmf-headless.md": {
	id: "processwire-cms-cmf-headless.md";
  slug: "processwire-cms-cmf-headless";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"processwire-velocita-fessibilita-sicurezza.md": {
	id: "processwire-velocita-fessibilita-sicurezza.md";
  slug: "processwire-velocita-fessibilita-sicurezza";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"programmazione-svg-tendenze.md": {
	id: "programmazione-svg-tendenze.md";
  slug: "programmazione-svg-tendenze";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"progressive-web-apps-con-react-vue-astro.md": {
	id: "progressive-web-apps-con-react-vue-astro.md";
  slug: "progressive-web-apps-con-react-vue-astro";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"pwa-amp-lavorano-bene-insieme.md": {
	id: "pwa-amp-lavorano-bene-insieme.md";
  slug: "pwa-amp-lavorano-bene-insieme";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
"siti-web-per-hotel.md": {
	id: "siti-web-per-hotel.md";
  slug: "siti-web-per-hotel";
  body: string;
  collection: "blog";
  data: InferEntrySchema<"blog">
} & { render(): Render[".md"] };
};
"docs": {
"documentation/code-blocks.mdx": {
	id: "documentation/code-blocks.mdx";
  slug: "documentation/code-blocks";
  body: string;
  collection: "docs";
  data: InferEntrySchema<"docs">
} & { render(): Render[".mdx"] };
"documentation/components.mdx": {
	id: "documentation/components.mdx";
  slug: "documentation/components";
  body: string;
  collection: "docs";
  data: InferEntrySchema<"docs">
} & { render(): Render[".mdx"] };
"documentation/index.mdx": {
	id: "documentation/index.mdx";
  slug: "documentation";
  body: string;
  collection: "docs";
  data: InferEntrySchema<"docs">
} & { render(): Render[".mdx"] };
"documentation/style-guide.mdx": {
	id: "documentation/style-guide.mdx";
  slug: "documentation/style-guide";
  body: string;
  collection: "docs";
  data: InferEntrySchema<"docs">
} & { render(): Render[".mdx"] };
"getting-started.mdx": {
	id: "getting-started.mdx";
  slug: "getting-started";
  body: string;
  collection: "docs";
  data: InferEntrySchema<"docs">
} & { render(): Render[".mdx"] };
"in-progress.mdx": {
	id: "in-progress.mdx";
  slug: "in-progress";
  body: string;
  collection: "docs";
  data: InferEntrySchema<"docs">
} & { render(): Render[".mdx"] };
};
"guides": {
"build-blog-using-astro-mdx.mdx": {
	id: "build-blog-using-astro-mdx.mdx";
  slug: "build-blog-using-astro-mdx";
  body: string;
  collection: "guides";
  data: InferEntrySchema<"guides">
} & { render(): Render[".mdx"] };
"using-next-auth-next-13.mdx": {
	id: "using-next-auth-next-13.mdx";
  slug: "using-next-auth-next-13";
  body: string;
  collection: "guides";
  data: InferEntrySchema<"guides">
} & { render(): Render[".mdx"] };
};
"highlights": {
"cms-headless-innovazione-costi.md": {
	id: "cms-headless-innovazione-costi.md";
  slug: "cms-headless-innovazione-costi";
  body: string;
  collection: "highlights";
  data: any
} & { render(): Render[".md"] };
"core-web-vitals-approcci-allo-sviluppo-web.md": {
	id: "core-web-vitals-approcci-allo-sviluppo-web.md";
  slug: "core-web-vitals-approcci-allo-sviluppo-web";
  body: string;
  collection: "highlights";
  data: any
} & { render(): Render[".md"] };
"jamastack-futuro.md": {
	id: "jamastack-futuro.md";
  slug: "jamastack-futuro";
  body: string;
  collection: "highlights";
  data: any
} & { render(): Render[".md"] };
"ottimizzazione-della-ricerca-vocale-il-futuro-del-seo.md": {
	id: "ottimizzazione-della-ricerca-vocale-il-futuro-del-seo.md";
  slug: "ottimizzazione-della-ricerca-vocale-il-futuro-del-seo";
  body: string;
  collection: "highlights";
  data: any
} & { render(): Render[".md"] };
"progressive-web-apps-con-react-vue-astro.md": {
	id: "progressive-web-apps-con-react-vue-astro.md";
  slug: "progressive-web-apps-con-react-vue-astro";
  body: string;
  collection: "highlights";
  data: any
} & { render(): Render[".md"] };
"siti-web-per-hotel.md": {
	id: "siti-web-per-hotel.md";
  slug: "siti-web-per-hotel";
  body: string;
  collection: "highlights";
  data: any
} & { render(): Render[".md"] };
};
"servizi": {
"content-strategy.md": {
	id: "content-strategy.md";
  slug: "content-strategy";
  body: string;
  collection: "servizi";
  data: InferEntrySchema<"servizi">
} & { render(): Render[".md"] };
"gestione-contenuti.md": {
	id: "gestione-contenuti.md";
  slug: "gestione-contenuti";
  body: string;
  collection: "servizi";
  data: InferEntrySchema<"servizi">
} & { render(): Render[".md"] };
"pwa.mdx": {
	id: "pwa.mdx";
  slug: "pwa";
  body: string;
  collection: "servizi";
  data: InferEntrySchema<"servizi">
} & { render(): Render[".mdx"] };
"servizio-ui-ux.md": {
	id: "servizio-ui-ux.md";
  slug: "servizio-ui-ux";
  body: string;
  collection: "servizi";
  data: InferEntrySchema<"servizi">
} & { render(): Render[".md"] };
"sviluppo-web-classico.md": {
	id: "sviluppo-web-classico.md";
  slug: "sviluppo-web-classico";
  body: string;
  collection: "servizi";
  data: InferEntrySchema<"servizi">
} & { render(): Render[".md"] };
"sviluppo-web-moderno.md": {
	id: "sviluppo-web-moderno.md";
  slug: "sviluppo-web-moderno";
  body: string;
  collection: "servizi";
  data: InferEntrySchema<"servizi">
} & { render(): Render[".md"] };
};
"showcase": {
"cms-processwire-diving.md": {
	id: "cms-processwire-diving.md";
  slug: "cms-processwire-diving";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".md"] };
"cms-processwire-sugherificio-molinas.md": {
	id: "cms-processwire-sugherificio-molinas.md";
  slug: "cms-processwire-sugherificio-molinas";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".md"] };
"dipellegrini-cms.md": {
	id: "dipellegrini-cms.md";
  slug: "dipellegrini-cms";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".md"] };
"pale-blue-dot.md": {
	id: "pale-blue-dot.md";
  slug: "pale-blue-dot";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".md"] };
"preview-markdown.md": {
	id: "preview-markdown.md";
  slug: "preview-markdown";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".md"] };
"progetto-web-gestione-porti-sardegna.md": {
	id: "progetto-web-gestione-porti-sardegna.md";
  slug: "progetto-web-gestione-porti-sardegna";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".md"] };
"sviluppo-web-moderno.md": {
	id: "sviluppo-web-moderno.md";
  slug: "sviluppo-web-moderno";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".md"] };
"third-post.md": {
	id: "third-post.md";
  slug: "third-post";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".md"] };
"using-mdx.mdx": {
	id: "using-mdx.mdx";
  slug: "using-mdx";
  body: string;
  collection: "showcase";
  data: InferEntrySchema<"showcase">
} & { render(): Render[".mdx"] };
};

	};

	type DataEntryMap = {
		
	};

	type AnyEntryMap = ContentEntryMap & DataEntryMap;

	export type ContentConfig = typeof import("./../src/content/config.js");
}
